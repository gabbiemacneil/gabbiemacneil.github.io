# Website
Hi, I'm Shaad! I am an Associate Professor at the UNH!
